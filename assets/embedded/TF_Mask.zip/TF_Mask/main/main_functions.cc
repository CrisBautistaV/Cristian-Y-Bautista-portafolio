/* Copyright 2020 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/


#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/system_setup.h"
#include "tensorflow/lite/schema/schema_generated.h"

#include "main_functions.h"
#include "model.h"
#include "output_handler.h"


const int kMaskIndex = 0;
//const int kNotMaskIndex = 1;

// Globals, used for compatibility with Arduino-style sketches.
namespace {
const tflite::Model* model = nullptr;
tflite::MicroInterpreter* interpreter = nullptr;
TfLiteTensor* input = nullptr;
TfLiteTensor* output = nullptr;

constexpr int kTensorArenaSize = 150*1024; //For contiguous memory allocation used by the framework
uint8_t tensor_arena[kTensorArenaSize];
}  // namespace

// The name of this function is important for Arduino compatibility.
void setup() {
  MicroPrintf("Setting up TFLite");
  // Map the model into a usable data structure. This doesn't involve any
  // copying or parsing, it's a very lightweight operation.
  model = tflite::GetModel(g_model);
  if (model->version() != TFLITE_SCHEMA_VERSION) {
    MicroPrintf("Model provided is schema version %d not equal to supported "
                "version %d.", model->version(), TFLITE_SCHEMA_VERSION);
    return;
  }

  // Pull in only the operation implementations we need.
  //A way for optimizing the memory
  static tflite::MicroMutableOpResolver<6> resolver;
  if (resolver.AddConv2D() != kTfLiteOk) {
    MicroPrintf("Conv2d no created!");
    return;
  }
  if (resolver.AddMaxPool2D() != kTfLiteOk) {
    MicroPrintf("MaxPool no created!");
    return;
  }
  if (resolver.AddReshape() != kTfLiteOk) {
    return;
  }
  if (resolver.AddFullyConnected() != kTfLiteOk) {
    MicroPrintf("Fully Not Created!");
    return;
  }
  if (resolver.AddRelu() != kTfLiteOk) {
    MicroPrintf("RELU Not Created!");
    return;
  }
  if (resolver.AddMean() != kTfLiteOk) {
    MicroPrintf("Avg Not Created!");
    return;
  }

  MicroPrintf("Good after Resolver!");
  // Build an interpreter to run the model with.
  static tflite::MicroInterpreter static_interpreter(
      model, resolver, tensor_arena, kTensorArenaSize);
  interpreter = &static_interpreter;

  MicroPrintf("Good after Interpreter!");
  // Allocate memory from the tensor_arena for the model's tensors.
  TfLiteStatus allocate_status = interpreter->AllocateTensors();
  MicroPrintf("Good after Allocation!");
  if (allocate_status != kTfLiteOk) {
    MicroPrintf("AllocateTensors() failed");
    return;
  }
  
  // Obtain pointers to the model's input and output tensors.
  input = interpreter->input(0);
  output = interpreter->output(0);

  MicroPrintf("All OK!");
}

// The name of this function is important for Arduino compatibility.
void loop(uint8_t *cameraBuf) {
  
  // Place the quantized input in the model's input tensor
  // Be carfeful with data type. Expected input is signed but camera frame is uint8
  int8_t pixel=0;
  for (int i=0; i<96*96; i++){
    pixel = (int8_t)(cameraBuf[i]-128);
    input->data.int8[i] = pixel;
  }
  
  // Run inference, and report any error
  TfLiteStatus invoke_status = interpreter->Invoke();
  if (invoke_status != kTfLiteOk) {
    MicroPrintf("Invoke failed");
    return;
  }

  // Obtain output from model's output tensor
  int8_t noMask_score = output->data.int8[kMaskIndex];
  //int8_t no_person_score = output->data.uint8[kNotAPersonIndex];

  // Output the results. A custom HandleOutput function can be implemented
  // for each supported hardware target.
  HandleOutput(noMask_score);


}
